﻿var academicAwardsTextDiv = document.getElementById("academicAwardsText");

var AcaAwardStar1 = document.getElementById("acaAwardStar1");
var AcaAwardStar2 = document.getElementById("acaAwardStar2");
var AcaAwardStar3 = document.getElementById("acaAwardStar3");
var AcaAwardStar4 = document.getElementById("acaAwardStar4");
var AcaAwardStar5 = document.getElementById("acaAwardStar5");
var AcaAwardStar6 = document.getElementById("acaAwardStar6");
var AcaAwardStar7 = document.getElementById("acaAwardStar7");
var AcaAwardStar8 = document.getElementById("acaAwardStar8");

var academicPanel = document.getElementById("pane-5");

var line3_1 = document.getElementById("line3-1");
var line3_2 = document.getElementById("line3-2");
var line3_3 = document.getElementById("line3-3");
var line3_4 = document.getElementById("line3-4");

AcaAwardStar1.addEventListener("mouseover", function () {
    academicAwardsTextDiv.innerHTML = "<p>[ KPMG Brain Bowl 2015 Winner ]</p>";
    assignStarCoordinates(AcaAwardStar1, academicPanel, line3_1, line3_2, line3_3, line3_4);
    assignTextCoordinates(academicAwardsTextDiv, academicPanel, line3_1, line3_2, line3_3, line3_4);
});

AcaAwardStar2.addEventListener("mouseover", function () {
    academicAwardsTextDiv.innerHTML = "<p>[ Highest Attainments in Math, ICT, Business Studies Year 12 ]</p>";
    assignStarCoordinates(AcaAwardStar2, academicPanel, line3_1, line3_2, line3_3, line3_4);
    assignTextCoordinates(academicAwardsTextDiv, academicPanel, line3_1, line3_2, line3_3, line3_4);
});

AcaAwardStar3.addEventListener("mouseover", function () {
    academicAwardsTextDiv.innerHTML = "<p>[ Highest Attainment in External Exams Year 12 (4 A’s in AS external exams) ]</p>";
    assignStarCoordinates(AcaAwardStar3, academicPanel, line3_1, line3_2, line3_3, line3_4);
    assignTextCoordinates(academicAwardsTextDiv, academicPanel, line3_1, line3_2, line3_3, line3_4);
});

AcaAwardStar4.addEventListener("mouseover", function () {
    academicAwardsTextDiv.innerHTML = "<p>[ Highest Attainment in A2 Biology ]</p>";
    assignStarCoordinates(AcaAwardStar4, academicPanel, line3_1, line3_2, line3_3, line3_4);
    assignTextCoordinates(academicAwardsTextDiv, academicPanel, line3_1, line3_2, line3_3, line3_4);
});

AcaAwardStar5.addEventListener("mouseover", function () {
    academicAwardsTextDiv.innerHTML = "<p>[ Highest Attainment in A2 Business Studies ]</p>";
    assignStarCoordinates(AcaAwardStar5, academicPanel, line3_1, line3_2, line3_3, line3_4);
    assignTextCoordinates(academicAwardsTextDiv, academicPanel, line3_1, line3_2, line3_3, line3_4);
});

AcaAwardStar6.addEventListener("mouseover", function () {
    academicAwardsTextDiv.innerHTML = "<p>[ Sixth Form Award for Highest Academic Attainment  ]</p>";
    assignStarCoordinates(AcaAwardStar6, academicPanel, line3_1, line3_2, line3_3, line3_4);
    assignTextCoordinates(academicAwardsTextDiv, academicPanel, line3_1, line3_2, line3_3, line3_4);
});

AcaAwardStar7.addEventListener("mouseover", function () {
    academicAwardsTextDiv.innerHTML = "<p>[ Cayman Islands Government ‘Proud of Them’ Award Recipient 2016 ]</p>";
    assignStarCoordinates(AcaAwardStar7, academicPanel, line3_1, line3_2, line3_3, line3_4);
    assignTextCoordinates(academicAwardsTextDiv, academicPanel, line3_1, line3_2, line3_3, line3_4);
});

AcaAwardStar8.addEventListener("mouseover", function () {
    academicAwardsTextDiv.innerHTML = "<p>[ Saxon MG Stock Market Investment Competition (Year 10, 11, 12) ]</p>";
    assignStarCoordinates(AcaAwardStar8, academicPanel, line3_1, line3_2, line3_3, line3_4);
    assignTextCoordinates(academicAwardsTextDiv, academicPanel, line3_1, line3_2, line3_3, line3_4);
});