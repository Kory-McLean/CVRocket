﻿var assignStarCoordinates = function (star,panel,  paramLine1, paramLine2, paramLine3, paramLine4) {
    var parentPos = panel.getBoundingClientRect(),
        starPos = star.getBoundingClientRect();
    var starXOffset = starPos.x - parentPos.x + 10;
    var starYOffset = starPos.y - parentPos.y + 10;
    paramLine1.setAttribute("x1", starXOffset);
    paramLine1.setAttribute("y1", starYOffset);

    paramLine2.setAttribute("x1", starXOffset);
    paramLine2.setAttribute("y1", starYOffset);

    paramLine3.setAttribute("x1", starXOffset);
    paramLine3.setAttribute("y1", starYOffset);

    paramLine4.setAttribute("x1", starXOffset);
    paramLine4.setAttribute("y1", starYOffset);
};

var assignTextCoordinates = function (text, panel,  paramLine1, paramLine2, paramLine3, paramLine4) {
    var parentPos = panel.getBoundingClientRect(),
        textPos = text.getBoundingClientRect();

    var firstTextXOffset = textPos.x - parentPos.x;
    var firstTextYOffset = textPos.y - parentPos.y + text.clientHeight - 15;

    var secondTextXOffset = textPos.x - parentPos.x + text.clientWidth;
    var secondTextYOffset = textPos.y - parentPos.y + 15;

    var thirdTextXOffset = textPos.x - parentPos.x;
    var thirdTextYOffset = textPos.y - parentPos.y + 15;

    var fourthTextXOffset = textPos.x - parentPos.x + text.clientWidth;
    var fourthTextYOffset = textPos.y - parentPos.y + text.clientHeight - 15;

    paramLine1.setAttribute("x2", firstTextXOffset);
    paramLine1.setAttribute("y2", firstTextYOffset);

    paramLine2.setAttribute("x2", secondTextXOffset);
    paramLine2.setAttribute("y2", secondTextYOffset);

    paramLine3.setAttribute("x2", thirdTextXOffset);
    paramLine3.setAttribute("y2", thirdTextYOffset);

    paramLine4.setAttribute("x2", fourthTextXOffset);
    paramLine4.setAttribute("y2", fourthTextYOffset);
}