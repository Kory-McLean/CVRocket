﻿var IntellectualSkillsTextDiv = document.getElementById("intellectualSkillsText");

var IntellectualSkillStar1 = document.getElementById("intellectualSkillStar1");
var IntellectualSkillStar2 = document.getElementById("intellectualSkillStar2");
var IntellectualSkillStar3 = document.getElementById("intellectualSkillStar3");
var IntellectualSkillStar4 = document.getElementById("intellectualSkillStar4");
var IntellectualSkillStar5 = document.getElementById("intellectualSkillStar5");
var IntellectualSkillStar6 = document.getElementById("intellectualSkillStar6");
var IntellectualSkillStar7 = document.getElementById("intellectualSkillStar7");
var IntellectualSkillStar8 = document.getElementById("intellectualSkillStar8");
var IntellectualSkillStar9 = document.getElementById("intellectualSkillStar9");

var intellectualPanel = document.getElementById("pane-7");

var line5_1 = document.getElementById("line5-1");
var line5_2 = document.getElementById("line5-2");
var line5_3 = document.getElementById("line5-3");
var line5_4 = document.getElementById("line5-4");

IntellectualSkillStar1.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Analysis and communication of Data  ]</p>";
    assignStarCoordinates(IntellectualSkillStar1, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
});

IntellectualSkillStar2.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Advanced Numeracy Skills ]</p>";
    assignStarCoordinates(IntellectualSkillStar2, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4)
});

IntellectualSkillStar3.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Ability to Deal with highly abstract concepts and present mathematical and logical arguments ]</p>";
    assignStarCoordinates(IntellectualSkillStar3, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4)
});

IntellectualSkillStar4.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Ability to analyze a problem and create solutions based upon reflective and creative thinking ]</p>";
    assignStarCoordinates(IntellectualSkillStar4, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4)
});

IntellectualSkillStar5.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Develop coherent justified arguments with consideration for ethical issues ]</p>";
    assignStarCoordinates(IntellectualSkillStar5, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4)
});

IntellectualSkillStar6.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Computer Coding (In the Python 3, HTML, C#, C, Java, Verilog, Jscript and CSS Languages) ]</p>";
    assignStarCoordinates(IntellectualSkillStar6, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4)
});

IntellectualSkillStar7.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Mathematical Skills in Calculus and Liner Algebra ]</p>";
    assignStarCoordinates(IntellectualSkillStar7, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4)
});

IntellectualSkillStar8.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Data structure analysis ]</p>";
    assignStarCoordinates(IntellectualSkillStar8, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4)
});

IntellectualSkillStar9.addEventListener("mouseover", function () {
    IntellectualSkillsTextDiv.innerHTML = "<p>[ Git version management. ]</p>";
    assignStarCoordinates(IntellectualSkillStar9, intellectualPanel, line5_1, line5_2, line5_3, line5_4);
    assignTextCoordinates(IntellectualSkillsTextDiv, intellectualPanel, line5_1, line5_2, line5_3, line5_4)
});