﻿var CommunityStar1 = document.getElementById("communityStar1");
var CommunityStar2 = document.getElementById("communityStar2");
var CommunityStar3 = document.getElementById("communityStar3");
var CommunityStar4 = document.getElementById("communityStar4");

var AthLeaderStar1 = document.getElementById("athLeaderStar1");
var AthLeaderStar2 = document.getElementById("athLeaderStar2");
var AthLeaderStar3 = document.getElementById("athLeaderStar3");
var AthLeaderStar4 = document.getElementById("athLeaderStar4");

var AcaLeaderStar1 = document.getElementById("acaLeaderStar1");
var AcaLeaderStar2 = document.getElementById("acaLeaderStar2");
var AcaLeaderStar3 = document.getElementById("acaLeaderStar3");
var AcaLeaderStar4 = document.getElementById("acaLeaderStar4");
var AcaLeaderStar5 = document.getElementById("acaLeaderStar5");

var leaderTextDiv = document.getElementById("leadershipTextDiv");

var leaderPanel = document.getElementById("pane-4");

var line2_1 = document.getElementById("line2-1");
var line2_2 = document.getElementById("line2-2");
var line2_3 = document.getElementById("line2-3");
var line2_4 = document.getElementById("line2-4");

//Commmunity Service Section
CommunityStar1.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Kiwanis Key Club: Member Years 10-12, Sergeant of arms in Year 12 ]</p>";
    assignStarCoordinates(CommunityStar1, leaderPanel,  line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel,  line2_1, line2_2, line2_3, line2_4);
});

CommunityStar2.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Junior Coach: ESM (Excel Sports Management) summer camp coach ]</p>";
    assignStarCoordinates(CommunityStar2, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

CommunityStar3.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Junior Coach: Academy Sports Club coach (2014-2016) ]</p>";
    assignStarCoordinates(CommunityStar3, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

CommunityStar4.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Junior Coach: Football 4 All, Autistic outreach program (Hosted by Academy Sports Club) ]</p>";
    assignStarCoordinates(CommunityStar4, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

//Athletic Leadership
AthLeaderStar1.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Captain U15 & U20 Cayman Islands National Team ]</p>";
    assignStarCoordinates(AthLeaderStar1, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

AthLeaderStar2.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Captain U17 & U23 Academy Sports Club  ]</p>";
    assignStarCoordinates(AthLeaderStar2, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

AthLeaderStar3.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Captain U18 St. Ignatius Varsity Team  ]</p>";
    assignStarCoordinates(AthLeaderStar3, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

AthLeaderStar4.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Captain (University of Toronto Development League) St. George Blacks ]</p>";
    assignStarCoordinates(AthLeaderStar4, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

//Academic Leadership
AcaLeaderStar1.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Deputy Head Boy ]</p>";
    assignStarCoordinates(AcaLeaderStar1, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

AcaLeaderStar2.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[	Prefect Head of Mentoring ]</p>";
    assignStarCoordinates(AcaLeaderStar2, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

AcaLeaderStar3.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Member of Charitable Fundraising Prefect Team ]</p>";
    assignStarCoordinates(AcaLeaderStar3, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

AcaLeaderStar4.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ STEM (Science Technology Engineering Mathematics) Ambassador ]</p>";
    assignStarCoordinates(AcaLeaderStar4, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});

AcaLeaderStar5.addEventListener("mouseover", function () {
    leaderTextDiv.innerHTML = "<p>[ Board Member of University of Toronto Students Soccer Association (Secretary) ]</p>";
    assignStarCoordinates(AcaLeaderStar5, leaderPanel, line2_1, line2_2, line2_3, line2_4);
    assignTextCoordinates(leaderTextDiv, leaderPanel, line2_1, line2_2, line2_3, line2_4);
});