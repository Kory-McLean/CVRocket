﻿var flames = document.getElementById("rocketShipThursters");
var position = $(window).scrollTop();

// should start at 0

$(window).scroll(function () {
    var scroll = $(window).scrollTop();
    if (scroll > position) {
        flames.style.visibility = "visible";
    } else if(scroll < position){
        flames.style.visibility = "hidden";
    }
    position = scroll;
});