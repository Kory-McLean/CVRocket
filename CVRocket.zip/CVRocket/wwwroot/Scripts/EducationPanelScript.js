﻿var HSstar1 = document.getElementById("HSstar1");
var HSstar2 = document.getElementById("HSstar2");
var HSstar3 = document.getElementById("HSstar3");
var HSstar4 = document.getElementById("HSstar4");
var HSstar5 = document.getElementById("HSstar5");

var UNIstar1 = document.getElementById("UNIstar1");
var UNIstar2 = document.getElementById("UNIstar2");
var UNIstar3 = document.getElementById("UNIstar3");

var line1_1 = document.getElementById("line1-1");
var line1_2 = document.getElementById("line1-2");
var line1_3 = document.getElementById("line1-3");
var line1_4 = document.getElementById("line1-4");

var eduPanel = document.getElementById('pane-3');

var eduTextDiv = document.getElementById("educationTextDiv");

HSstar1.addEventListener("mouseover", function () {
    eduTextDiv.innerHTML = "<p>[ High School Diploma: Honors Graduate ]</p>";
    assignStarCoordinates(HSstar1, eduPanel, line1_1, line1_2, line1_3, line1_4);
    assignTextCoordinates(eduTextDiv, eduPanel,  line1_1, line1_2, line1_3, line1_4);
});

HSstar2.addEventListener("mouseover", function () {
    eduTextDiv.innerHTML = "<p>[ Accumulative GPA over 5 years: 4.14 (On a 4.5 Scale) ]</p>";
    assignStarCoordinates(HSstar2, eduPanel, line1_1, line1_2, line1_3, line1_4);
    assignTextCoordinates(eduTextDiv, eduPanel,  line1_1, line1_2, line1_3, line1_4);
});

HSstar3.addEventListener("mouseover", function () {
    eduTextDiv.innerHTML = "<p>[ Highest Achievement in AS External Exams in 4 subjects ]</p>";
    assignStarCoordinates(HSstar3, eduPanel, line1_1, line1_2, line1_3, line1_4);
    assignTextCoordinates(eduTextDiv, eduPanel,  line1_1, line1_2, line1_3, line1_4);
});

HSstar4.addEventListener("mouseover", function () {
    eduTextDiv.innerHTML = "<p>[ High Passes in A2 External Exams in Math(A), I.C.T.(B), Biology(B) and Business Studies(A*) ]</p>";
    assignStarCoordinates(HSstar4, eduPanel,  line1_1, line1_2, line1_3, line1_4);
    assignTextCoordinates(eduTextDiv, eduPanel,  line1_1, line1_2, line1_3, line1_4);
});

HSstar5.addEventListener("mouseover", function () {
    eduTextDiv.innerHTML = "<p>[ Spare Star - Delete ]</p>";
    assignStarCoordinates(HSstar5, eduPanel, line1_1, line1_2, line1_3, line1_4);
    assignTextCoordinates(eduTextDiv, eduPanel, line1_1, line1_2, line1_3, line1_4);
});

UNIstar1.addEventListener("mouseover", function () {
    eduTextDiv.innerHTML = "<p>[ Honors Bachelor of Science Degree with a Specialist in Computer Science ]</p>";
    assignStarCoordinates(UNIstar1, eduPanel,  line1_1, line1_2, line1_3, line1_4);
    assignTextCoordinates(eduTextDiv, eduPanel, line1_1, line1_2, line1_3, line1_4);
});

UNIstar2.addEventListener("mouseover", function () {
    eduTextDiv.innerHTML = "<p>[ First Year Cumulative GPA: 3.49 (On a 4.0 Scale) ]</p>";
    assignStarCoordinates(UNIstar2, eduPanel, line1_1, line1_2, line1_3, line1_4);
    assignTextCoordinates(eduTextDiv, eduPanel,  line1_1, line1_2, line1_3, line1_4);
});

UNIstar3.addEventListener("mouseover", function () {
    eduTextDiv.innerHTML = "<p>[ Expected date for graduation: June 2020 ]</p>";
    assignStarCoordinates(UNIstar3, eduPanel,  line1_1, line1_2, line1_3, line1_4);
    assignTextCoordinates(eduTextDiv, eduPanel,  line1_1, line1_2, line1_3, line1_4);
});