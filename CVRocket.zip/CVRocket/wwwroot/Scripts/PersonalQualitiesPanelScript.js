﻿var PersonalQualityTextDiv = document.getElementById("personalQualityText");

var PersonalQualityStar1 = document.getElementById("personalQualityStar1");
var PersonalQualityStar2 = document.getElementById("personalQualityStar2");
var PersonalQualityStar3 = document.getElementById("personalQualityStar3");
var PersonalQualityStar4 = document.getElementById("personalQualityStar4");
var PersonalQualityStar5 = document.getElementById("personalQualityStar5");

var personalQualitiesPanel = document.getElementById("pane-8");

var line6_1 = document.getElementById("line6-1");
var line6_2 = document.getElementById("line6-2");
var line6_3 = document.getElementById("line6-3");
var line6_4 = document.getElementById("line6-4");

PersonalQualityStar1.addEventListener("mouseover", function () {
    PersonalQualityTextDiv.innerHTML = "<p>[ Ability to communicate to peers ]</p>";
    assignStarCoordinates(PersonalQualityStar1, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
    assignTextCoordinates(PersonalQualityTextDiv, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
});

PersonalQualityStar2.addEventListener("mouseover", function () {
    PersonalQualityTextDiv.innerHTML = "<p>[ Ability to work in teams effectively ]</p>";
    assignStarCoordinates(PersonalQualityStar2, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
    assignTextCoordinates(PersonalQualityTextDiv, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
});

PersonalQualityStar3.addEventListener("mouseover", function () {
    PersonalQualityTextDiv.innerHTML = "<p>[ Able to lead and direct in high stress situations ]</p>";
    assignStarCoordinates(PersonalQualityStar3, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
    assignTextCoordinates(PersonalQualityTextDiv, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
});

PersonalQualityStar4.addEventListener("mouseover", function () {
    PersonalQualityTextDiv.innerHTML = "<p>[ Can relate to peers on a personal level as well as through work ]</p>";
    assignStarCoordinates(PersonalQualityStar4, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
    assignTextCoordinates(PersonalQualityTextDiv, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
});

PersonalQualityStar5.addEventListener("mouseover", function () {
    PersonalQualityTextDiv.innerHTML = "<p>[ Able to apply logical thinking process in order to solve problems ]</p>";
    assignStarCoordinates(PersonalQualityStar5, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
    assignTextCoordinates(PersonalQualityTextDiv, personalQualitiesPanel, line6_1, line6_2, line6_3, line6_4);
});