﻿var athAwardTextDiv = document.getElementById("athleticAwardsText");

var ATHawardStar1 = document.getElementById("athAwardStar1");
var ATHawardStar2 = document.getElementById("athAwardStar2");
var ATHawardStar3 = document.getElementById("athAwardStar3");
var ATHawardStar4 = document.getElementById("athAwardStar4");
var ATHawardStar5 = document.getElementById("athAwardStar5");
var ATHawardStar6 = document.getElementById("athAwardStar6");
var ATHawardStar7 = document.getElementById("athAwardStar7");
var ATHawardStar8 = document.getElementById("athAwardStar8");

var athleticPanel = document.getElementById("pane-6");

var line4_1 = document.getElementById("line4-1");
var line4_2 = document.getElementById("line4-2");
var line4_3 = document.getElementById("line4-3");
var line4_4 = document.getElementById("line4-4");

ATHawardStar1.addEventListener("mouseover", function () {
    athAwardTextDiv.innerHTML = "<p>[ Academy Sports club Leadership Award U17 ]</p>";
    assignStarCoordinates(ATHawardStar1, athleticPanel, line4_1, line4_2, line4_3, line4_4);
    assignTextCoordinates(athAwardTextDiv, athleticPanel, line4_1, line4_2, line4_3, line4_4);
});

ATHawardStar2.addEventListener("mouseover", function () {
    athAwardTextDiv.innerHTML = "<p>[ Fosters First Division Champion 2014/15 ]</p>";
    assignStarCoordinates(ATHawardStar2, athleticPanel, line4_1, line4_2, line4_3, line4_4);
    assignTextCoordinates(athAwardTextDiv, athleticPanel, line4_1, line4_2, line4_3, line4_4);
});

ATHawardStar3.addEventListener("mouseover", function () {
    athAwardTextDiv.innerHTML = "<p>[ CONCACAF D License recipient ]</p>";
    assignStarCoordinates(ATHawardStar3, athleticPanel, line4_1, line4_2, line4_3, line4_4);
    assignTextCoordinates(athAwardTextDiv, athleticPanel, line4_1, line4_2, line4_3, line4_4);
});

ATHawardStar4.addEventListener("mouseover", function () {
    athAwardTextDiv.innerHTML = "<p>[ University of Toronto Development League Fall season 2016 Champion ]</p>";
    assignStarCoordinates(ATHawardStar4, athleticPanel, line4_1, line4_2, line4_3, line4_4);
    assignTextCoordinates(athAwardTextDiv, athleticPanel, line4_1, line4_2, line4_3, line4_4);
});

ATHawardStar5.addEventListener("mouseover", function () {
    athAwardTextDiv.innerHTML = "<p>[ University of Toronto Development League Winter season 2017 Runner-Up ]</p>";
    assignStarCoordinates(ATHawardStar5, athleticPanel, line4_1, line4_2, line4_3, line4_4);
    assignTextCoordinates(athAwardTextDiv, athleticPanel, line4_1, line4_2, line4_3, line4_4);
});

ATHawardStar6.addEventListener("mouseover", function () {
    athAwardTextDiv.innerHTML = "<p>[ University of Toronto Development League Fall season 2017 Runner-Up ]</p>";
    assignStarCoordinates(ATHawardStar6, athleticPanel, line4_1, line4_2, line4_3, line4_4);
    assignTextCoordinates(athAwardTextDiv, athleticPanel, line4_1, line4_2, line4_3, line4_4);
});

ATHawardStar7.addEventListener("mouseover", function () {
    athAwardTextDiv.innerHTML = "<p>[ Neymar Jr’s Five Presented by Red Bull Football Tournament Quarter-Finalist ]</p>";
    assignStarCoordinates(ATHawardStar7, athleticPanel, line4_1, line4_2, line4_3, line4_4);
    assignTextCoordinates(athAwardTextDiv, athleticPanel, line4_1, line4_2, line4_3, line4_4);
});

ATHawardStar8.addEventListener("mouseover", function () {
    athAwardTextDiv.innerHTML = "<p>[ TRY Cup Fall 2016 Champion (A tournament composed of Representatives from York University, Ryerson University and the University of Toronto) ]</p>";
    assignStarCoordinates(ATHawardStar8, athleticPanel, line4_1, line4_2, line4_3, line4_4);
    assignTextCoordinates(athAwardTextDiv, athleticPanel, line4_1, line4_2, line4_3, line4_4);
});